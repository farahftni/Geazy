package com.example.zakat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etGoldWeight;
    EditText etGoldValue;
    RadioGroup rgGoldType;
    RadioButton rbSelected;
    Button btnCalc;
    TextView tvTotalValue;
    TextView tvZakatPayable;
    TextView calc;
    TextView tvTotalZakat;

    double goldTypeWeight=0;

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater= getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.geazy:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                break;

            case R.id.about:
                Intent intent1 = new Intent(this, AboutActivity.class);
                startActivity(intent1);
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etGoldWeight = (EditText) findViewById(R.id.goldWeight);
        etGoldValue = (EditText) findViewById(R.id.goldValue);
        rgGoldType = (RadioGroup) findViewById(R.id.type);
        btnCalc = (Button) findViewById(R.id.btnCalc);
        tvTotalValue = (TextView) findViewById(R.id.totalValue);
        tvZakatPayable = (TextView) findViewById(R.id.zakatPayable);
        calc = (TextView) findViewById(R.id.calc);
        tvTotalZakat = (TextView) findViewById(R.id.totalZakat);

        btnCalc.setOnClickListener(this);
    }

    public void checkButton(View view){

        int radioId = rgGoldType.getCheckedRadioButtonId();

        rbSelected = findViewById(radioId);

        if(rbSelected.getText().equals("Keep")){
            goldTypeWeight = 85;
        }
        else if(rbSelected.getText().equals("Wear")){
            goldTypeWeight = 200;
        }

    }

    @Override
    public void onClick(View view) {

try {
    switch (view.getId()) {

        case R.id.btnCalc:

            double goldWeight = Double.parseDouble(etGoldWeight.getText().toString());
            double goldValue = Double.parseDouble(etGoldValue.getText().toString());

            double totValue = goldWeight * goldValue;
            double zktPayable = (goldWeight - goldTypeWeight) * goldValue;

            if (zktPayable < 0) {
                zktPayable = 0;
            }

            double totZakat = zktPayable * 0.025;

            tvTotalValue.setText(totValue + "");
            tvZakatPayable.setText(zktPayable + "");
            calc.setText("(" + goldWeight + "-" + goldTypeWeight + ") X " + goldValue);
            tvTotalZakat.setText(totZakat + "");

            break;
    }
}catch(java.lang.NumberFormatException nfe){
    Toast.makeText(this,"Please enter a valid number", Toast.LENGTH_SHORT).show();
} catch (Exception exp){
    Toast.makeText(this, "Unknown Exception" + exp.getMessage(), Toast.LENGTH_SHORT).show();

    Log.d("Exception", exp.getMessage());
}

    }



}